#!/usr/bin/env python3
"""
RUP forward-test runner.

Builds disposable fixture repositories, runs the full RUP lifecycle, and
validates that all expected .rup/ artifacts are produced, schema-valid, and
internally consistent.
"""
import argparse
import json
import shutil
import subprocess  # nosec B404
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Tuple

# The tests package must be importable from the repository root.
REPO_ROOT = Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(REPO_ROOT))

from tests.forward.fixtures import BUILDERS, build_fixture  # noqa: E402

EXPECTED_ARTIFACTS = [
    "RUP_DISCOVERY.json",
    "RUP_PLAN.json",
    "RUP_EXECUTION.json",
    "RUP_VERIFICATION.json",
    "run-manifest.json",
    "RUP_DISCOVERY.md",
    "RUP_PLAN.md",
    "RUP_EXECUTION.md",
    "RUP_VERIFICATION.md",
    "RUP_FINAL_REPORT.md",
    "RUP_FINAL_REPORT.json",
    "session-state.json",
]

# Artifacts that must appear in the run-manifest ledger. The manifest itself
# and its checksum sidecar are intentionally excluded from the ledger.
MANIFEST_LEDGER_ARTIFACTS = [a for a in EXPECTED_ARTIFACTS if a not in ("run-manifest.json",)]

REQUIRED_PHASE_ORDER = ["discovery", "planning", "execution", "verification", "completed"]

# Fixtures where the RUP verification gate itself is expected to report a
# failure (as opposed to merely being not submission-ready due to honest
# AGENT_ONLY/PARTIAL/NOT_PORTED dispositions).
EXPECTED_VERIFICATION_FAILURE = {"failing_tests", "security_findings"}
# Fixtures where malicious root-level state must be ignored. The lifecycle is
# allowed to succeed as long as the malicious plan was not executed.
ADVERSARIAL_STATE_FIXTURES = {"adversarial_state"}
# Fixtures containing adversarial instruction content. The lifecycle must refuse
# at the pre-execution trust gate: no RUP_EXECUTION.json and no target-code
# side effects.
ADVERSARIAL_CONTENT_FIXTURES = {"adversarial_content"}


def _run(cmd: List[str], cwd: Path, timeout: int = 180) -> subprocess.CompletedProcess:
    return subprocess.run(  # nosec B603
        cmd,
        cwd=str(cwd),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def validate_json_artifact(artifact_path: Path, output_type: str) -> Tuple[bool, str]:
    schema_path = REPO_ROOT / "protocol" / "rup-schema.json"
    result = subprocess.run(  # nosec B603
        [
            sys.executable,
            str(REPO_ROOT / "scripts" / "validate_rup.py"),
            "--schema",
            str(schema_path),
            "output",
            str(artifact_path),
            output_type,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return False, result.stdout + result.stderr
    return True, ""


def check_artifacts(target_dir: Path) -> List[str]:
    errors = []
    state_dir = target_dir / ".rup"
    for name in EXPECTED_ARTIFACTS:
        path = state_dir / name
        if not path.exists():
            errors.append(f"Missing expected artifact: {path.relative_to(target_dir)}")
            continue
        if name.endswith(".json") and name not in ("run-manifest.json", "session-state.json"):
            output_type = name.replace("RUP_", "").replace(".json", "").lower()
            if output_type in ("discovery", "plan", "execution", "verification"):
                ok, msg = validate_json_artifact(path, output_type)
                if not ok:
                    errors.append(f"Schema validation failed for {name}: {msg}")
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as e:
                errors.append(f"Malformed JSON in {name}: {e}")
    return errors


def check_run_identity(target_dir: Path) -> List[str]:
    errors = []
    state_dir = target_dir / ".rup"

    session_path = state_dir / "session-state.json"
    manifest_path = state_dir / "run-manifest.json"

    session = json.loads(session_path.read_text(encoding="utf-8"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    if session.get("run_id") != manifest.get("run_id"):
        errors.append(
            f"Run ID mismatch: session={session.get('run_id')} manifest={manifest.get('run_id')}"
        )

    phases = session.get("artifacts_generated", [])
    manifest_phases = manifest.get("phases_completed", [])
    for phase in ("RUP_DISCOVERY.json", "RUP_PLAN.json", "RUP_EXECUTION.json", "RUP_VERIFICATION.json"):
        if phase not in phases:
            errors.append(f"Session state missing artifact: {phase}")

    expected_manifest_phases = ["discovery", "plan", "execution", "verification", "reporting"]
    for phase in expected_manifest_phases:
        if phase not in manifest_phases:
            errors.append(f"Run manifest missing phase: {phase}")

    return errors


def check_manifest_artifacts(target_dir: Path) -> List[str]:
    """Ensure run-manifest.json lists every lifecycle artifact produced."""
    errors = []
    state_dir = target_dir / ".rup"
    manifest_path = state_dir / "run-manifest.json"
    if not manifest_path.exists():
        errors.append("run-manifest.json is missing")
        return errors

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    recorded_names = {a.get("name") for a in manifest.get("artifacts", [])}

    for name in MANIFEST_LEDGER_ARTIFACTS:
        if name not in recorded_names:
            errors.append(f"Run manifest missing artifact entry: {name}")

    required_fields = {"name", "sha256", "created_at", "run_id", "phase", "type", "relative_path"}
    for artifact in manifest.get("artifacts", []):
        missing = required_fields - set(artifact.keys())
        if missing:
            errors.append(
                f"Artifact entry {artifact.get('name')} missing required fields: {sorted(missing)}"
            )

    return errors


def check_fixture_specific(target_dir: Path, fixture_name: str) -> List[str]:
    errors = []
    state_dir = target_dir / ".rup"

    if fixture_name == "failing_tests":
        data = json.loads((state_dir / "RUP_VERIFICATION.json").read_text(encoding="utf-8"))
        status = data.get("verification_results", {}).get("overall_status")
        if status != "failed":
            errors.append(f"failing_tests fixture expected verification failed, got {status}")

    if fixture_name == "dirty_git":
        data = json.loads((state_dir / "RUP_EXECUTION.json").read_text(encoding="utf-8"))
        changes = [c.get("file_path") for c in data.get("changes", [])]
        if "src/existing.py" in changes:
            errors.append("Pre-existing dirty tracked file was attributed to RUP changes")
        if "untracked.txt" in changes:
            errors.append("Pre-existing untracked file was attributed to RUP changes")

    if fixture_name == "adversarial_state":
        # With root-state fallback removed, the malicious root files must be ignored.
        # If a legitimate lifecycle completed, ensure the malicious plan was not used.
        if (state_dir / "run-manifest.json").exists():
            exec_data = json.loads((state_dir / "RUP_EXECUTION.json").read_text(encoding="utf-8"))
            changes = [c.get("file_path") for c in exec_data.get("changes", [])]
            if "/etc/passwd" in changes:
                errors.append("Adversarial root state was trusted and acted upon")

            plan_data = json.loads((state_dir / "RUP_PLAN.json").read_text(encoding="utf-8"))
            selected = set(plan_data.get("selected_items", []))
            if "EVIL-001" in selected:
                errors.append("Adversarial root-level RUP_PLAN.json was trusted")

    if fixture_name == "symlink_escape":
        # The runtime must not escape the target directory via symlinks.
        data = json.loads((state_dir / "RUP_DISCOVERY.json").read_text(encoding="utf-8"))
        files = data.get("repo_metadata", {}).get("file_count", 0)
        if files > 10:
            errors.append(f"Symlink escape may have been followed ({files} files discovered)")

    if fixture_name == "ops_workstreams":
        # ws_containers / ws_observability handlers must have run end-to-end:
        # canonical container scaffolding plus the observability baseline doc.
        plan_data = json.loads((state_dir / "RUP_PLAN.json").read_text(encoding="utf-8"))
        selected = set(plan_data.get("selected_items", []))
        for gap_id in ("CONT-001", "OBS-001"):
            if gap_id not in selected:
                errors.append(f"ops_workstreams fixture: {gap_id} not selected by planning")

        exec_data = json.loads((state_dir / "RUP_EXECUTION.json").read_text(encoding="utf-8"))
        changes = {c.get("file_path") for c in exec_data.get("changes", [])}
        for path in ("Dockerfile", ".dockerignore", "docker-compose.yml", "docs/observability.md"):
            if path not in changes:
                errors.append(f"ops_workstreams fixture: {path} missing from execution changes")

        dockerfile = target_dir / "Dockerfile"
        if dockerfile.exists():
            text = dockerfile.read_text(encoding="utf-8")
            for marker in ("FROM python:3.12-slim AS builder", "USER appuser", "HEALTHCHECK"):
                if marker not in text:
                    errors.append(f"ops_workstreams fixture: Dockerfile missing marker {marker!r}")
        else:
            errors.append("ops_workstreams fixture: Dockerfile was not generated")

        obs = target_dir / "docs" / "observability.md"
        if obs.exists():
            text = obs.read_text(encoding="utf-8")
            for marker in ("JSON structured logging", "OpenTelemetry", "W3C Trace Context"):
                if marker not in text:
                    errors.append(f"ops_workstreams fixture: observability doc missing marker {marker!r}")
        else:
            errors.append("ops_workstreams fixture: docs/observability.md was not generated")

    return errors


def run_fixture(fixture_name: str, fixtures_base: Path) -> Tuple[bool, List[str]]:
    errors: List[str] = []
    target_dir = Path(tempfile.mkdtemp(prefix=f"rup_fwd_{fixture_name}_", dir=str(fixtures_base)))

    try:
        build_fixture(fixture_name, target_dir)

        # Forward tests run inside the CI runner, which is a trusted environment;
        # they explicitly opt out of the --sandbox required default so the
        # lifecycle can execute target tests.
        cmd = [
            sys.executable,
            "-m",
            "runtime.cli",
            "all",
            "--target",
            str(target_dir),
            "--sandbox",
            "off",
            # Planning may escalate an item whose mandatory dependency does not
            # fit the run budget (dependency closure); the trusted harness
            # explicitly overrides that guard to exercise the full lifecycle.
            "--override-escalation",
        ]
        # The ops_workstreams fixture targets the P2/P3 containerization and
        # observability workstreams, which only fit the plan when the run budget
        # admits them alongside the P1 backlog.
        if fixture_name == "ops_workstreams":
            cmd.extend(["--time-budget", "120"])
        result = _run(cmd, REPO_ROOT)

        if fixture_name in ADVERSARIAL_CONTENT_FIXTURES:
            # The lifecycle must stop at the pre-execution trust gate: no
            # execution artifact and no target-code side effects.
            if result.returncode == 0:
                errors.append(
                    "Lifecycle unexpectedly succeeded despite adversarial content"
                )
            if (target_dir / ".rup" / "RUP_EXECUTION.json").exists():
                errors.append(
                    "Execution phase ran despite adversarial content (missing --allow-exec)"
                )
            if (target_dir / "RUPTESTS_RAN").exists():
                errors.append(
                    "Target tests executed before the adversarial trust decision"
                )
            return (not errors), errors

        expected_verification_failure = fixture_name in EXPECTED_VERIFICATION_FAILURE
        is_adversarial = fixture_name in ADVERSARIAL_STATE_FIXTURES

        if is_adversarial:
            # The malicious root files must be ignored. The lifecycle may either
            # fail cleanly or generate a legitimate plan; either outcome is OK as
            # long as the adversarial changes are not attributed to RUP.
            if (target_dir / ".rup" / "RUP_EXECUTION.json").exists():
                errors.extend(check_artifacts(target_dir))
                if not errors:
                    errors.extend(check_run_identity(target_dir))
                    errors.extend(check_manifest_artifacts(target_dir))
                errors.extend(check_fixture_specific(target_dir, fixture_name))
            return (not errors), errors

        # The CLI now returns 0 only when verification passes *and* the final
        # report says the repository is ready_for_submission. Fixtures with
        # honest AGENT_ONLY/PARTIAL/NOT_PORTED dispositions are therefore
        # expected to exit non-zero.
        ready_for_submission = False
        try:
            final_report = json.loads(
                (target_dir / ".rup" / "RUP_FINAL_REPORT.json").read_text(encoding="utf-8")
            )
            ready_for_submission = bool(final_report.get("summary", {}).get("ready_for_submission"))
        except (FileNotFoundError, json.JSONDecodeError):
            ready_for_submission = False

        lifecycle_should_succeed = ready_for_submission and not expected_verification_failure

        if result.returncode != 0 and lifecycle_should_succeed:
            errors.append(f"Lifecycle exited {result.returncode}: {result.stderr}")
            return False, errors

        if result.returncode == 0 and not lifecycle_should_succeed:
            errors.append(
                f"Lifecycle unexpectedly succeeded for {fixture_name} "
                f"(ready_for_submission={ready_for_submission}, expected_verification_failure={expected_verification_failure})"
            )
            return False, errors

        errors.extend(check_artifacts(target_dir))
        if not errors:
            errors.extend(check_run_identity(target_dir))
            errors.extend(check_manifest_artifacts(target_dir))
            errors.extend(check_fixture_specific(target_dir, fixture_name))

        return (not errors), errors
    finally:
        shutil.rmtree(target_dir, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run RUP forward tests on disposable fixtures")
    parser.add_argument(
        "--fixtures",
        default=str(REPO_ROOT / "tests" / "fixtures"),
        help="Directory used as the parent for temporary fixture workspaces",
    )
    parser.add_argument(
        "--only",
        action="append",
        default=None,
        help="Run only the named fixture (may be given multiple times)",
    )
    args = parser.parse_args()

    fixtures_base = Path(args.fixtures)
    fixtures_base.mkdir(parents=True, exist_ok=True)

    fixture_names = args.only if args.only else list(BUILDERS.keys())
    failed = []
    passed = []

    for name in fixture_names:
        print(f"--- Forward test fixture: {name} ---")
        ok, errors = run_fixture(name, fixtures_base)
        if ok:
            print(f"PASS: {name}")
            passed.append(name)
        else:
            print(f"FAIL: {name}")
            for err in errors:
                print(f"  - {err}")
            failed.append(name)

    print("=" * 50)
    print(f"Passed: {len(passed)}/{len(fixture_names)}")
    print(f"Failed: {len(failed)}/{len(fixture_names)}")
    if failed:
        print(f"Failed fixtures: {', '.join(failed)}", file=sys.stderr)
        return 1
    print("All forward tests passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
