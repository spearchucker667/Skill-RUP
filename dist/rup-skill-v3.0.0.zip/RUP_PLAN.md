# plan\n\n\n\n## Generated Data\n```json\n{
  "backlog": [],
  "selected_items": [],
  "execution_order": [],
  "risk_analysis": {
    "breaking_changes_possible": false,
    "requires_manual_review": false,
    "rollback_complexity": "trivial",
    "affected_packages": []
  },
  "estimated_effort": {
    "total_minutes": 0,
    "confidence": "high",
    "breakdown": {}
  }
}\n```\n