# Skill-RUP — GitHub Documentation & Public Release Readiness Agent Handoff

## Mission

Prepare `https://github.com/spearchucker667/Skill-RUP` for a professional public GitHub release by establishing complete, accurate, maintainable documentation, community-health files, repository metadata, and release-readiness evidence.

Local workspace:

```text
/Users/super_user/Projects/Skill-RUP/
```

Canonical behavioral source:

```text
https://github.com/spearchucker667/RUP-Protocol
```

This is not a cosmetic README pass. The finished repository must look and operate like a deliberate open-source project. Do not broadly refactor runtime code, but do not claim the repository is release-ready if documentation work exposes technical release blockers.

---

## 1. Inspect Before Editing

Start from the actual current `main` branch and re-resolve HEAD:

```bash
cd "/Users/super_user/Projects/Skill-RUP"
git status --short --branch
git rev-parse HEAD
git log -5 --oneline --decorate
git remote -v
find . -maxdepth 3 -type f | sort
```

At handoff creation time, the latest reviewed commit was:

```text
244219157c53ab0c99fbc1cab17347a57dca8e63
fix: remediate mock data and enable genuine capability mapping and execution
```

Do not assume that SHA is still current. Record actual HEAD in the final report.

Observed public documentation currently includes:

```text
README.md
LICENSE
AGENTS.md
SKILL.md

docs/
  CAPABILITY_MAPPING.md
  INSTALL.md
  SOURCE_AUDIT.md
  SOURCE_AUTHORITY.md
  USER_GUIDE.md
  summary_of_work.md

.github/
  workflows/
```

The public community-health layer is incomplete. The repository currently lacks the standard contribution/security/support/governance/release documents and GitHub issue/PR intake files expected from a polished public project.

The root license is Apache-2.0. Verify the exact upstream RUP license and preserve its provenance/notice obligations for copied or derived canonical material.

---

## 2. Required Outcomes

Complete all of the following in the same run:

1. Rewrite/polish `README.md` to professional public-release quality.
2. Create complete GitHub community-health files.
3. Establish user, developer, security, portability, architecture, artifact, compatibility, troubleshooting, and release documentation.
4. Establish clear licensing/provenance/third-party attribution.
5. Create professional issue forms and PR template.
6. Establish release notes/versioning/release-check documentation.
7. Create a coherent `docs/README.md` index.
8. Remove public machine-specific paths, internal-work-order language, stale placeholders, and unsupported claims.
9. Validate links, commands, YAML, and required-file presence.
10. Finish with an evidence-backed public-release readiness decision.

Do not optimize for file count. Each document needs a distinct audience and purpose.

---

## 3. Documentation Rules

### Accuracy over marketing

Never claim `production-grade`, `fully supported`, `100% complete`, `secure`, `portable`, `validated`, or `release ready` without evidence.

Use concrete wording such as:

```text
Skill-RUP preserves the canonical RUP v3 protocol and schema under `protocol/`, exposes an agent-facing `SKILL.md`, provides workflow projections, and includes a Python 3.11+ deterministic runtime.
```

### Canonical authority

Keep these roles explicit everywhere:

- `protocol/rup-protocol.yaml` — canonical RUP behavioral/process authority.
- `protocol/rup-schema.json` — canonical validation authority.
- `SKILL.md` — compact agent runtime contract/router.
- `workflows/` — agent-readable workflow projections.
- `runtime/` and `scripts/` — deterministic implementation/support tools.
- `docs/` — explanatory/user/developer/security/release material.

If docs conflict with canonical protocol/schema, canonical sources win.

### Public hygiene

Search public-facing files for internal residue:

```bash
rg -n '/Users/|super_user|\.work orders|TODO|TBD|FIXME|placeholder|your-org'   README.md AGENTS.md SKILL.md docs .github workflows 2>/dev/null || true
```

Replace machine-specific examples with generic forms such as `/path/to/Skill-RUP` and `/path/to/target-repo`.

Do not expose secrets, private emails, tokens, credentials, local-only assumptions, or internal work-order notes.

### One canonical home per topic

Use README as navigation, not as a duplicate of every guide.

---

## 4. Root-Level Files

Create or substantially update the following.

### `README.md`

Mandatory professional rewrite. Recommended structure:

```markdown
# Skill-RUP
<one-sentence value proposition>
<real badges only>

## What is Skill-RUP?
## Why it exists
## Relationship to RUP Protocol
## Core capabilities
## RUP lifecycle
## Quick start
## Installation
## Usage
## Workflow routing
## Architecture
## Safety and trust model
## Compatibility
## Generated artifacts
## Validation
## Documentation
## Contributing
## Security
## Releases
## License and attribution
```

The first screen must answer: what it is, who it is for, what problem it solves, how it relates to RUP Protocol, and that it is an agent skill with deterministic supporting runtime.

Suggested positioning, adjusted to actual state:

```text
Skill-RUP is a portable agent skill that translates RUP Protocol v3 into an agent-readable workflow and deterministic repository-upgrade runtime. It preserves the canonical Discovery → Planning → Execution → Verification lifecycle while exposing the protocol through SKILL.md, workflow projections, validation schemas, and supporting runtime tools.
```

Use only real badges backed by real repository checks. Candidates: CI, Validate Skill, Forward Tests once trustworthy, Security only once real, Apache-2.0, RUP v3.0.0, Python 3.11+.

Add a lifecycle diagram when useful:

```mermaid
flowchart LR
  D[Discovery] --> P[Planning]
  P --> E[Execution]
  E --> V[Verification]
  V --> R[Report / Handoff]
```

Include the shortest truthful quick start. Do not invent a full-run CLI command if one does not exist.

Add a documentation table linking the deeper docs.

### `CONTRIBUTING.md`

Cover:

- project scope
- prerequisites/local setup
- architecture orientation
- source-authority rules
- contribution workflow
- code/doc style
- tests/validation
- generated-file policy
- capability-map updates
- protocol/schema change policy
- security-sensitive changes
- commit convention
- PR expectations
- issue filing
- changelog expectations

Test every command before publishing it.

### `SECURITY.md`

Create responsible disclosure guidance covering supported versions, private reporting path, what to include, coordination, and public-issue prohibition for vulnerabilities.

Explicit scope examples:

- traversal/symlink escape
- arbitrary command execution/shell injection
- prompt-injection boundary failure
- secret leakage
- unsafe Git operations
- archive traversal
- state/provenance manipulation
- malicious repository content
- dependency confusion/hallucination

If GitHub private vulnerability reporting is not enabled, do not pretend it is.

### `CODE_OF_CONDUCT.md`

Use a recognized current standard such as Contributor Covenant. Fill contact/enforcement placeholders with a real project channel.

### `SUPPORT.md`

Explain where users should report usage questions, bugs, feature requests, docs issues, security reports, upstream RUP semantic issues, and agent-platform integration problems.

### `CHANGELOG.md`

Use a Keep a Changelog/SemVer-compatible format:

```markdown
# Changelog
## [Unreleased]
### Added
### Changed
### Fixed
### Security
```

Do not invent historical releases.

### `GOVERNANCE.md`

Keep governance simple and transparent: maintainership, decision-making, canonical-source authority, contribution acceptance, security decisions, releases, protocol divergence, deprecation.

### `NOTICE` and `THIRD_PARTY_NOTICES.md`

Determine whether NOTICE is legally/operationally appropriate. At minimum create a clear third-party provenance record for canonical RUP material, with source, version/commit, license, and usage. Never imply copied upstream material changed license merely because Skill-RUP uses Apache-2.0.

### `CITATION.cff`

Recommended if appropriate. Use only verified project metadata; do not invent DOI or affiliations.

---

## 5. Required `docs/` Coverage

Create `docs/README.md` as the documentation index and establish the following substantive guides.

### `docs/INSTALL.md`

Expand current minimal content. Cover prerequisites, Python 3.11+, Python dependencies, clone/local install, generic global skill install, project-local install, verified agent-platform layouts, Windows/macOS/Linux/WSL notes, upgrades, uninstall, and installation verification.

Never require upstream `RUP-Protocol` to be cloned at runtime.

### `docs/USER_GUIDE.md`

Cover full lifecycle and individual routes. Only document commands/routes actually exposed by `SKILL.md`:

```text
/RUP
/RUP discovery
/RUP plan
/RUP execute
/RUP verify
/RUP report
/RUP rollback
/RUP handoff
```

Also document read-only usage, artifacts, resume/handoff, rollback, monorepo/hotfix/security/CI/docs/tests workstreams, and common failures.

### `docs/ARCHITECTURE.md`

Explain:

```text
SKILL.md
  -> workflows/
  -> protocol/rup-protocol.yaml
  -> protocol/rup-schema.json
  -> runtime/
  -> schemas/
  -> provenance/
  -> generated artifacts
```

Document authority boundaries, phase roles, runtime support, capability mapping, state/artifact flow, source-audit flow, validation, and packaging. Add a useful Mermaid component/sequence diagram.

### `docs/ARTIFACT_CONTRACTS.md`

Re-establish this removed document. For each actual artifact document producer, purpose, schema, required fields, lifecycle phase, overwrite semantics, trust level, secret-handling rule, and example location.

Candidate artifacts to inspect:

```text
RUP_DISCOVERY.json / .md
RUP_PLAN.json / .md
RUP_EXECUTION.json / .md
RUP_VERIFICATION.json / .md
RUP_FINAL_REPORT.json / .md
RUP_RUN_MANIFEST.json
RUP_SESSION_STATE.json
RUP_ROLLBACK_PLAN.*
RUP_HANDOFF.*
```

Mark planned/nonexistent artifacts explicitly instead of presenting them as implemented.

### `docs/PORTABILITY.md`

Re-establish this removed guide. Build an evidence-based matrix for macOS arm64/x86_64, Linux x86_64/arm64, Windows 11, WSL2, and Termux where applicable. Distinguish `Verified`, `Targeted`, `Expected`, and `Unsupported`.

Cover Python, Git, path semantics, shell independence, encoding, temp files, symlinks/junctions, line endings, and optional external verification tools.

### `docs/SECURITY_MODEL.md`

Re-establish the technical threat model. Distinguish it from root `SECURITY.md`.

Cover untrusted repository content, prompt injection, traversal/symlink escape, command injection, env leakage, secrets, malicious config, YAML bombs, file-size limits, destructive Git operations, dependency hallucination, network use, archive safety, state/provenance tampering, implemented controls, and known limitations.

Do not portray simple keyword detection as comprehensive prompt-injection defense.

### `docs/DEVELOPMENT.md`

Re-establish developer setup, architecture, generators, authored-vs-generated files, tests, adding workflows/schemas, canonical-source updates, provenance regeneration, packaging, and documentation checks.

### `docs/RELEASES.md`

Define versioning, relationship between Skill-RUP version and canonical RUP version, release prerequisites, changelog, package regeneration, manifest/hash verification, GitHub release process, post-release verification, rollback/yank policy.

Hard invariant:

```text
source tree used for release == source tree represented by manifest/package
```

Never release a stale `dist/` archive.

### `docs/COMPATIBILITY.md`

Matrix for Skill-RUP version, RUP Protocol version, Python, Git, OS, agent loaders, and optional tools. Keep platform support separate from capability support.

### `docs/TROUBLESHOOTING.md`

Use symptom → cause → resolution sections for imports, missing dependencies, Git unavailable/not initialized, no tests, validator errors, invalid artifacts, path-jail failures, permissions, stale generated docs/capability map, stale package, and skill-discovery failures.

### `docs/FAQ.md`

Answer common public questions: Skill-RUP vs RUP Protocol, runtime dependency on upstream, whether execution mutates repos, discovery-only mode, agent platforms, language scope, untrusted input model, unavailable verification tools, support/security, and licensing.

### Existing source docs

Review/update:

```text
docs/SOURCE_AUTHORITY.md
docs/SOURCE_AUDIT.md
docs/CAPABILITY_MAPPING.md
```

Ensure they are understandable to public contributors and do not unnecessarily expose local absolute paths.

---

## 6. `docs/README.md` Index

Create a compact index grouped by audience:

```markdown
# Skill-RUP Documentation

## Users
- Installation
- User Guide
- Troubleshooting
- FAQ

## Integrators / Agent Platforms
- Architecture
- Compatibility
- Portability
- Artifact Contracts

## Contributors
- Development
- Contributing
- Releases

## Security / Provenance
- Security Model
- Security Policy
- Source Authority
- Source Audit
- Capability Mapping
```

---

## 7. GitHub Community Health Layer

Target:

```text
.github/
  CODEOWNERS
  pull_request_template.md
  release.yml
  ISSUE_TEMPLATE/
    bug_report.yml
    feature_request.yml
    documentation.yml
    config.yml
  workflows/
    ...existing workflows...
```

Add `dependabot.yml` only if it is useful. Add `FUNDING.yml` only if a real funding destination exists.

### Bug issue form

Request summary, expected/actual behavior, reproduction, Skill-RUP version/commit, RUP version, OS, Python, agent platform, target repo characteristics, logs with a prominent “redact secrets” warning.

### Feature issue form

Request problem, proposed capability, affected RUP workflow/phase, canonical-semantics relationship, alternatives, compatibility impact, and confirmation it is not a vulnerability disclosure.

### Documentation issue form

Request affected document, incorrect/missing content, proposed clarification, references.

### `config.yml`

Route vulnerabilities away from public issues. Link appropriate support/upstream channels. Do not create a public security-advisory issue form.

### PR template

Use:

```markdown
## Summary
## Why
## Changes
## Validation
## RUP capability/source impact
## Security / compatibility impact
## Checklist
```

Checklist should cover tests, docs, changelog, generated artifacts, canonical semantics, secret/local-path hygiene, and security implications.

### CODEOWNERS

Only add verified maintainer handles. Consider sensitive ownership for `/protocol/`, `/schemas/`, `runtime/security.py`, `.github/workflows/`, and security policy files.

### `release.yml`

Configure release-note categories if GitHub-generated release notes are intended: breaking, features, fixes, security, docs, dependencies, maintenance.

---

## 8. GitHub Repository Metadata

Inspect with authenticated `gh` where available:

```bash
gh repo view spearchucker667/Skill-RUP --json   name,description,homepageUrl,isPrivate,licenseInfo,repositoryTopics,defaultBranchRef
```

Desired public state:

- public repository
- concise professional description
- focused topics
- Apache-2.0 correctly detected
- `main` default branch
- README/security/contributing/code-of-conduct files recognized by GitHub

Recommended topic candidates:

```text
rup
agent-skills
ai-agents
repository-automation
devtools
software-quality
security
ci-cd
python
```

Possible description:

```text
Portable agent skill implementing RUP Protocol v3 for structured repository discovery, planning, execution, verification, and release-readiness workflows.
```

Adjust claims to current implementation evidence.

---

## 9. README Public Quality Bar

The README must have:

- professional hierarchy and grammar
- no internal work-order language
- no local absolute paths
- no giant badge wall
- no fake statuses
- clear value proposition above the fold
- useful quick start early
- clear upstream relationship
- docs navigation
- contribution/security/release links
- license/provenance statement
- implementation status grounded in evidence

Avoid AI-style filler such as `flawlessly`, `seamless`, `fully authenticated`, `100% complete`.

Preferred terminology:

```text
Skill-RUP         this repository / skill implementation
RUP Protocol      canonical upstream protocol
RUP runtime       deterministic supporting runtime
Target repository repository being analyzed/upgraded
Agent platform    host that loads/invokes the skill
```

---

## 10. AGENTS.md Public Hygiene

Review `AGENTS.md` and remove machine-specific workspace details from public instructions.

Good:

```text
Repository root: resolve from current checkout.
Canonical RUP sources: protocol/.
Local `.reference/`, if present, is source-audit material and never a runtime dependency.
```

Avoid public instructions containing `/Users/super_user/...`.

Preserve source-authority and agent safety rules.

---

## 11. Internal Development Material

Review `docs/summary_of_work.md`. A running agent session ledger is not normally primary public documentation.

Choose deliberately:

1. move it under `development/`;
2. rename it as an internal developer log;
3. remove it from release-facing docs if no longer required; or
4. retain it only if AGENTS/process rules require it and it contains no private/local information.

Reconcile any AGENTS.md requirement before moving/removing it.

---

## 12. Examples Documentation

Review `examples/README.md` and examples. Explain which artifacts are synthetic, which schema they target, how to validate them, and that examples are not evidence of actual runtime execution. Commands must use Skill-RUP paths unless explicitly labeled as upstream RUP commands.

---

## 13. Release Artifacts

The repository contains `dist/`. Public release docs must explain package contents, exclusions, manifest, hash verification, source-tag relationship, and reproducibility.

Before a release:

```bash
python scripts/package_skill.py
unzip -l dist/rup-skill-v3.0.0.zip
shasum -a 256 dist/rup-skill-v3.0.0.zip
```

Adjust version dynamically if packaging/version policy changes.

Verify the archive excludes `.git/`, `.reference/`, `.work orders/`, `.venv/`, caches, logs, secrets, host-specific paths, and unnecessary development-only material.

Do not publish stale dist artifacts.

---

## 14. Documentation Validation

Add lightweight deterministic validation, preferably `scripts/check_docs.py`, that can run offline for repository-relative checks.

Checks should include:

- required public files exist
- README/docs internal links resolve
- no `/Users/<name>/` paths
- no release-facing TODO/TBD/FIXME placeholders
- issue-form YAML parses
- README links to install/security/contributing/license/docs
- docs index matches actual files

Use an external link checker only if appropriately pinned and maintainable.

---

## 15. Release Notes Contract

Create a release template in `docs/RELEASES.md`:

```markdown
# Skill-RUP vX.Y.Z

## Summary
## RUP Protocol Compatibility
- Canonical RUP version:
- Canonical source commit:

## Added
## Changed
## Fixed
## Security
## Compatibility
## Upgrade Notes
## Validation
- CI:
- Tests:
- Protocol validation:
- Capability audit:
- Package verification:

## Artifacts
- Archive:
- SHA-256:
- Manifest:

## Known Limitations
## Source / License Notes
```

Never state PASS based solely on a workflow name. Use real run/command evidence.

---

## 16. Public Release Readiness Gates

Do not report `PUBLIC RELEASE READY` unless all applicable gates pass.

### Documentation

- [ ] professional README
- [ ] CONTRIBUTING
- [ ] SECURITY
- [ ] CODE_OF_CONDUCT
- [ ] SUPPORT
- [ ] CHANGELOG
- [ ] GOVERNANCE
- [ ] INSTALL
- [ ] USER_GUIDE
- [ ] ARCHITECTURE
- [ ] ARTIFACT_CONTRACTS
- [ ] PORTABILITY
- [ ] SECURITY_MODEL
- [ ] DEVELOPMENT
- [ ] RELEASES
- [ ] COMPATIBILITY
- [ ] TROUBLESHOOTING
- [ ] FAQ
- [ ] docs index
- [ ] attribution/notice decision documented

### GitHub health

- [ ] bug form
- [ ] feature form
- [ ] docs form
- [ ] issue config routes security privately
- [ ] PR template
- [ ] CODEOWNERS if applicable
- [ ] repo description/topics reviewed
- [ ] GitHub recognizes security/contribution/code-of-conduct files

### Quality

- [ ] zero broken internal Markdown links
- [ ] zero public local-user absolute paths
- [ ] zero unresolved release-facing placeholders
- [ ] all commands shown publicly tested or clearly labeled illustrative
- [ ] no contradictory version/license/support claims
- [ ] no unsupported feature/platform claims

### Technical release gates

Documentation cannot hide technical failures. Before stable release verify:

- [ ] runtime tests pass
- [ ] canonical protocol validation passes
- [ ] capability-map check passes and checks real implementation existence/coverage
- [ ] security workflow performs real checks
- [ ] release workflow actually packages/verifies artifacts
- [ ] forward tests fail when verification fails
- [ ] `dist/` regenerated from current source
- [ ] no known P0 release blockers remain

If any technical gate fails, finish docs but classify repository `NOT PUBLIC RELEASE READY` and list blockers.

---

## 17. Existing Workflow Review

Inspect at minimum:

```text
.github/workflows/ci.yml
.github/workflows/validate-skill.yml
.github/workflows/forward-tests.yml
.github/workflows/security-scan.yml
.github/workflows/release-package.yml
```

Do not broaden into a runtime rewrite, but do not add badges or release claims for no-op/invalid workflows.

Prior review found that security/release workflows had checkout-only behavior and validator invocations needed scrutiny. Re-check current HEAD; do not assume they remain unchanged.

---

## 18. Suggested Public Tree

```text
README.md
LICENSE
NOTICE                       # if appropriate
THIRD_PARTY_NOTICES.md
CHANGELOG.md
CONTRIBUTING.md
SECURITY.md
CODE_OF_CONDUCT.md
SUPPORT.md
GOVERNANCE.md
CITATION.cff                 # if appropriate
AGENTS.md
SKILL.md

.github/
  CODEOWNERS
  pull_request_template.md
  release.yml
  ISSUE_TEMPLATE/
    bug_report.yml
    feature_request.yml
    documentation.yml
    config.yml
  workflows/
    ...

docs/
  README.md
  INSTALL.md
  USER_GUIDE.md
  ARCHITECTURE.md
  ARTIFACT_CONTRACTS.md
  PORTABILITY.md
  SECURITY_MODEL.md
  DEVELOPMENT.md
  RELEASES.md
  COMPATIBILITY.md
  TROUBLESHOOTING.md
  FAQ.md
  SOURCE_AUTHORITY.md
  SOURCE_AUDIT.md
  CAPABILITY_MAPPING.md
```

Do not add empty/performance-only files. If NOTICE/CITATION/CODEOWNERS are not appropriate, document why in the final report.

---

## 19. Versioning Policy

Verify current version from `SKILL.md`, tags/releases, and package naming. Do not assume Skill-RUP must forever share the same number as RUP Protocol.

Recommended policy unless maintainer intent is explicitly lockstep:

```text
Skill-RUP follows semantic versioning for the skill implementation. Each release separately records the canonical RUP Protocol version and commit it implements.
```

---

## 20. License / Provenance Rules

Verify and document:

1. license for original Skill-RUP implementation/docs;
2. license for copied/derived canonical RUP protocol/schema/validators;
3. attribution/notice obligations;
4. whether a NOTICE is appropriate;
5. whether root Apache-2.0 could mislead readers about upstream material without third-party attribution.

Never silently relicense copied upstream material.

---

## 21. Validation Sequence

After edits run:

```bash
cd "/Users/super_user/Projects/Skill-RUP"

git status --short
find .github docs -maxdepth 3 -type f | sort

rg -n '/Users/|super_user|TODO|TBD|FIXME|PLACEHOLDER|your-org'   README.md CONTRIBUTING.md SECURITY.md CODE_OF_CONDUCT.md SUPPORT.md   GOVERNANCE.md CHANGELOG.md AGENTS.md docs .github 2>/dev/null || true

python3 --version
python3 -m runtime.cli --help
python3 -m pytest tests/
python3 scripts/build_capability_map.py --check
python3 scripts/validate_rup.py --help

# Run the validator with its actual supported syntax after inspecting --help.
# Run docs/link checker if added.

python3 scripts/package_skill.py

git diff --check
git diff --stat
git diff
```

Do not publish validator examples until their exact syntax is tested.

---

## 22. Final Release-Readiness Table

Produce:

| Area | Status | Evidence | Blocker |
|---|---|---|---|
| README | PASS/FAIL | link/section validation | ... |
| Community health | PASS/FAIL | recognized files | ... |
| Security policy | PASS/FAIL | SECURITY.md | ... |
| Public path hygiene | PASS/FAIL | rg scan | ... |
| Docs links | PASS/FAIL | checker | ... |
| Runtime tests | PASS/FAIL | command | ... |
| Protocol validation | PASS/FAIL | command | ... |
| Capability audit | PASS/FAIL | command | ... |
| Security workflow | PASS/FAIL | real checks | ... |
| Release package freshness | PASS/FAIL | manifest/hash | ... |
| Public release | READY/NOT READY | aggregate | ... |

---

## 23. Explicit Do-Not Rules

Do not:

- rewrite canonical RUP semantics for documentation convenience;
- advertise unverified platforms as verified;
- claim tests/security/CI pass without evidence;
- leave local absolute paths in public docs;
- publish private emails, secrets, tokens, or credentials;
- use fake badges;
- create a public exploit-report issue form;
- copy upstream docs without attribution/licensing review;
- leave `TBD` placeholders in release-facing docs;
- invent release history, contributors, support SLAs, or organizations;
- destroy provenance/source lineage;
- make `.reference/` a runtime dependency;
- call stale ZIPs release artifacts;
- call the repository production-grade merely because docs improved;
- document commands that were not checked against current CLI behavior.

---

## 24. Implementation Order

### Phase A — Inventory
1. Resolve current HEAD and status.
2. Inventory root/docs/.github/releases/tags/workflows.
3. Search private paths/placeholders.
4. Inspect README/license/source authority.
5. Record missing health files.

### Phase B — Information architecture
1. Define canonical home for each topic.
2. Create docs index.
3. Establish terminology/version language.
4. Avoid duplication.

### Phase C — Root public docs
Create/update README, CONTRIBUTING, SECURITY, CODE_OF_CONDUCT, SUPPORT, CHANGELOG, GOVERNANCE, and notices/citation as appropriate.

### Phase D — Deep docs
Create/update INSTALL, USER_GUIDE, ARCHITECTURE, ARTIFACT_CONTRACTS, PORTABILITY, SECURITY_MODEL, DEVELOPMENT, RELEASES, COMPATIBILITY, TROUBLESHOOTING, FAQ, and reconcile provenance docs.

### Phase E — GitHub health
Create issue forms, PR template, CODEOWNERS, release config, and appropriate repo metadata.

### Phase F — Validation
Run public-path, placeholder, link, YAML, command, test, protocol, capability, and packaging checks.

### Phase G — Release classification
Return exactly one:

```text
PUBLIC RELEASE READY
PUBLIC RELEASE READY WITH DOCUMENTED NON-BLOCKING LIMITATIONS
NOT PUBLIC RELEASE READY
```

Use `NOT PUBLIC RELEASE READY` whenever a P0 technical/release blocker remains.

---

## 25. Final Report Required

Before ending, report:

### Documentation created
List each new file.

### Documentation updated
List each rewritten/expanded file.

### GitHub files created
List issue forms/templates/config.

### Public-hygiene changes
List local paths/internal wording/broken links/misleading claims removed or corrected.

### Validation
For each command include command, exit code, PASS/FAIL, and important output.

### Release readiness
State one of the three classifications above and enumerate blockers by severity.

### Git state
Report HEAD before/after, `git status`, files added/modified/removed.

Do not claim a push/tag/release occurred unless it actually occurred.

---

## Definition of Done

A first-time visitor must be able to understand, without external context:

- what Skill-RUP is;
- what RUP Protocol is;
- how they relate;
- how to install and invoke the skill;
- what lifecycle it implements;
- what artifacts it produces;
- what platforms/environments are verified;
- how its safety model works;
- how to contribute;
- how to report bugs and vulnerabilities;
- how releases are versioned and validated;
- which licenses apply;
- where upstream material originated;
- what the current stability/release status actually is.

The public repository must also have coherent GitHub community-health coverage, a professional README, no obvious local-development residue, and an evidence-backed release-readiness statement.

Do not stop after rewriting `README.md`. The objective is full GitHub documentation coverage and public-release readiness.
