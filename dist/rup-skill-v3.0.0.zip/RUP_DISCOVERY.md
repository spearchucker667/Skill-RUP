# discovery-report\n\n\n\n## Generated Data\n```json\n{
  "repo_metadata": {
    "name": "Skill-RUP",
    "primary_language": "typescript",
    "repo_type": "application",
    "loc": 377998,
    "file_count": 1130
  },
  "languages": [
    {
      "name": "typescript",
      "percentage": 78.75,
      "lockfile_present": false
    },
    {
      "name": "rust",
      "percentage": 12.31,
      "lockfile_present": false
    },
    {
      "name": "python",
      "percentage": 5.15,
      "lockfile_present": false
    },
    {
      "name": "javascript",
      "percentage": 3.79,
      "lockfile_present": false
    }
  ],
  "tooling": {
    "test_framework": "pytest"
  },
  "gaps": [],
  "risk_assessment": {
    "overall_risk": "low",
    "technical_debt_score": 0,
    "production_readiness_score": 100
  }
}\n```\n